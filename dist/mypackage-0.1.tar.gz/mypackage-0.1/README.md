###package
"""This package was created to demonstrate my first python package"""

###Building this package locally
'python setup.py sdist'

###install from Github
'url='https://github.com/krazimira/mypackage'

### updating this package in github
'pip install -- upgrade url='https://github.com/krazimira/mypackage'
